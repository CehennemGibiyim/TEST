@echo off
title TikTok Sandik Radari - Kurulum ve Baslatma
color 0E
cd /d "%~dp0"

echo ==========================================
echo       TIKTOK RADAR PRO MASAUSTU
echo ==========================================
echo Ilk kez aciyorsaniz bu islem 2-3 dakika surebilir.
echo Paketler (Electron, Puppeteer vb.) indiriliyor...
echo.

call npm install

IF NOT EXIST "node_modules\electron" (
  echo.
  echo [HATA] Moduller kurulamadi! Lutfen bilgisayarinizda Node.js kurulu oldugundan emin olun.
  pause
  exit
)

cls
echo ==========================================
echo       SISTEM BASLATILIYOR!
echo ==========================================
echo Masaustu uygulamasi aciliyor...
echo Arkadaki komut penceresini KAPATMAYIN! (Botlarin calismasi icin acik kalmalidir)
echo.

call npm start
pause
