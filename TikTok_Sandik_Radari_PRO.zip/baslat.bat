@echo off
title TikTok Sandik Radari - Sistematik Baglanti
color 0E
cd /d "%~dp0"

echo ==========================================
echo       TIKTOK SANDIK RADARI BASLATICI
echo ==========================================
echo Moduller indiriliyor... Lutfen bekleyin.
echo (Bu islem internet hizina bagli olarak biraz surebilir)
echo.

call npm install

IF NOT EXIST "node_modules\tiktok-live-connector" (
  echo.
  echo [HATA] Moduller kurulamadi! Lutfen internet baglantinizi veya Windows izinlerini kontrol edin.
  pause
  exit
)

cls
echo ==========================================
echo       RADAR SUNUCUSU AKTIF EDILDI!
echo ==========================================
echo - Sistem arka planda calisiyor...
echo - Simdi tarayicidaki panele donun.
echo - "Baglan" butonuna tiklayin.
echo.
echo LUTFEN BU SIYAH EKRANI KAPATMAYIN! (Pusuya yatmak icin acik kalmali)
echo ==========================================
echo.

node server.js
pause