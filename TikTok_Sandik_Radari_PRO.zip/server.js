const { WebcastPushConnection } = require('tiktok-live-connector');
const WebSocket = require('ws');

const port = 3000; 
const wss = new WebSocket.Server({ port: port });
console.log("Radar Sunucusu " + port + " portunda aktif! Panele baglanmayi bekliyor...");

let trackedUsers = {};

wss.on('connection', function connection(ws) {
  console.log("Harika! Radar paneli baglandi.");

  ws.on('message', function incoming(message) {
    const data = JSON.parse(message);

    if (data.action === 'add_user' && data.username) {
      const username = data.username;
      
      if (trackedUsers[username]) return;

      console.log(`Radara eklendi: @${username}`);
      const ttConnection = new WebcastPushConnection(username);
      trackedUsers[username] = ttConnection;

      ttConnection.connect().then(state => {
          ws.send(JSON.stringify({ type: 'status', user: username, status: 'connected' }));
      }).catch(err => {
          ws.send(JSON.stringify({ type: 'status', user: username, status: 'error' }));
          delete trackedUsers[username];
      });

      ttConnection.on('envelope', envData => {
          ws.send(JSON.stringify({
              type: 'chest',
              user: username,
              data: {
                  coins: envData.treasureBoxData?.coins || "Belirsiz",
                  time: new Date().toLocaleTimeString(),
                  // Tiktok API'sinden gelen süre saniye cinsindendir. Yoksa varsayılan 180s (3 dakika).
                  duration: envData.treasureBoxData?.duration || 180 
              }
          }));
      });
    }

    if (data.action === 'remove_user' && data.username) {
        const username = data.username;
        if (trackedUsers[username]) {
            console.log(`Suresi doldu/Kaldirildi: @${username}`);
            trackedUsers[username].disconnect();
            delete trackedUsers[username];
        }
    }
  });

  ws.on('close', () => {
      for (const user in trackedUsers) {
          if(trackedUsers[user]) {
              trackedUsers[user].disconnect();
              delete trackedUsers[user];
          }
      }
  });
});