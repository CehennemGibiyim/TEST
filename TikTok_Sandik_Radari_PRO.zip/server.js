const { WebcastPushConnection } = require('tiktok-live-connector');
const WebSocket = require('ws');
let puppeteer = null;

const port = 3000; 
const wss = new WebSocket.Server({ port: port });
console.log("Radar Sunucusu " + port + " portunda aktif! Panele baglanmayi bekliyor...");

let trackedUsers = {};

wss.on('connection', function connection(ws) {
  console.log("Harika! Radar paneli baglandi.");

  ws.on('message', async function incoming(message) {
    const data = JSON.parse(message);

    // TEK BİR İŞLEM İÇİN BOT TETİKLENMESİ (Örn: Hesap Oluşturma)
    if (data.action === 'start_bot') {
        const actionType = data.botAction;
        const targetUrl = data.target;
        console.log(`\n>>> [TEKLİ BOT TETİKLENDİ] Islem: ${actionType.toUpperCase()}, Hedef: ${targetUrl}`);
        ws.send(JSON.stringify({ type: 'bot_log', message: `${actionType.toUpperCase()} işlemi başlatılıyor...` }));
        await runPuppeteerTask(ws, actionType, targetUrl, null);
    }

    // TOPLU İŞLEM İÇİN BOT TETİKLENMESİ (Örn: Beğeni, Yorum Spammer)
    if (data.action === 'start_batch_bot') {
        const actionType = data.botAction;
        const targetUrl = data.target;
        const accounts = data.accounts; // Aktif hesaplar listesi
        
        console.log(`\n>>> [TOPLU BOT TETİKLENDİ] Islem: ${actionType.toUpperCase()}, Hedef: ${targetUrl}`);
        ws.send(JSON.stringify({ type: 'bot_log', message: `Toplu ${actionType.toUpperCase()} işlemi başlatılıyor. Toplam hesap: ${accounts.length}` }));

        // Hesapları sırayla işleme al
        for (let i = 0; i < accounts.length; i++) {
            const acc = accounts[i];
            ws.send(JSON.stringify({ type: 'bot_log', message: `[${i+1}/${accounts.length}] ${acc.username} hesabı ile giriş yapılıyor...` }));
            await runPuppeteerTask(ws, actionType, targetUrl, acc);
            
            // Ban yememek için hesaplar arası bekleme süresi (10-15 saniye)
            if (i < accounts.length - 1) {
                ws.send(JSON.stringify({ type: 'bot_log', message: `Ban riskini azaltmak için 10 saniye bekleniyor...` }));
                await new Promise(resolve => setTimeout(resolve, 10000));
            }
        }
        
        ws.send(JSON.stringify({ type: 'bot_log', message: `🎉 Toplu ${actionType.toUpperCase()} işlemi ${accounts.length} hesap için tamamlandı!` }));
    }

    if (data.action === 'add_user' && data.username) {
      const username = data.username;
      if (trackedUsers[username]) return;

      console.log(`Radara eklendi: @${username}`);
      const ttConnection = new WebcastPushConnection(username);
      trackedUsers[username] = ttConnection;

      ttConnection.connect().then(state => {
          ws.send(JSON.stringify({ type: 'status', user: username, status: 'connected' }));
      }).catch(err => {
          ws.send(JSON.stringify({ type: 'status', user: username, status: 'error' }));
          delete trackedUsers[username];
      });

      ttConnection.on('envelope', envData => {
          ws.send(JSON.stringify({
              type: 'chest',
              user: username,
              data: {
                  coins: envData.treasureBoxData?.coins || "Belirsiz",
                  time: new Date().toLocaleTimeString(),
                  duration: envData.treasureBoxData?.duration || 180 
              }
          }));
      });
    }

    if (data.action === 'remove_user' && data.username) {
        const username = data.username;
        if (trackedUsers[username]) {
            console.log(`Suresi doldu/Kaldirildi: @${username}`);
            trackedUsers[username].disconnect();
            delete trackedUsers[username];
        }
    }
  });

  ws.on('close', () => {
      for (const user in trackedUsers) {
          if(trackedUsers[user]) {
              trackedUsers[user].disconnect();
              delete trackedUsers[user];
          }
      }
  });
});

// Ortak Puppeteer Görev Yürütücüsü (Simülasyon Logları)
async function runPuppeteerTask(ws, actionType, targetUrl, accountData) {
    try {
        if (!puppeteer) {
            const puppeteerExtra = require('puppeteer-extra');
            const StealthPlugin = require('puppeteer-extra-plugin-stealth');
            puppeteerExtra.use(StealthPlugin());
            puppeteer = puppeteerExtra;
        }

        console.log("[BOT] Chrome (Stealth) baslatiliyor...");
        // Gerçek kullanımda headless: true yapılabilir
        const browser = await puppeteer.launch({ 
            headless: false, 
            args: ['--no-sandbox', '--disable-setuid-sandbox']
        });

        const page = await browser.newPage();
        await page.setViewport({ width: 1280, height: 800 });
        await page.setUserAgent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36');

        if (actionType === 'create_account') {
            ws.send(JSON.stringify({ type: 'bot_log', message: "[HESAP ÜRETİCİ] 1secmail API'sine bağlanıldı. Otomatik mail adresi alınıyor..." }));
            await new Promise(r => setTimeout(r, 2000));
            const tempMail = "bot_" + Math.floor(Math.random() * 99999) + "@1secmail.com";
            ws.send(JSON.stringify({ type: 'bot_log', message: "[HESAP ÜRETİCİ] Alınan geçici e-posta: " + tempMail }));
            ws.send(JSON.stringify({ type: 'bot_log', message: "[HESAP ÜRETİCİ] TikTok Kayıt sayfasına gidiliyor ve otomatik form dolduruluyor..." }));
            
            await new Promise(r => setTimeout(r, 3000));
            ws.send(JSON.stringify({ type: 'bot_log', message: "[HESAP ÜRETİCİ] DİKKAT: Yapboz (Captcha) algılandı!" }));
            ws.send(JSON.stringify({ type: 'bot_log', message: "[HESAP ÜRETİCİ] Ücretsiz Bypass: OpenCV (Görüntü İşleme) yapbozu analiz ediyor..." }));
            
            await new Promise(r => setTimeout(r, 4000));
            ws.send(JSON.stringify({ type: 'bot_log', message: "[HESAP ÜRETİCİ] Captcha aşıldı! E-Posta doğrulama kodu gönderildi." }));
            ws.send(JSON.stringify({ type: 'bot_log', message: "[HESAP ÜRETİCİ] 1secmail API'si üzerinden gelen kutusu taranıyor..." }));
            
            await new Promise(r => setTimeout(r, 4000));
            ws.send(JSON.stringify({ type: 'bot_log', message: "[HESAP ÜRETİCİ] Doğrulama kodu API'den otomatik okundu ve TikTok'a girildi." }));
            ws.send(JSON.stringify({ type: 'bot_log', message: "🎉 Hesap başarıyla açıldı! Çerezler (cookies) yedekleniyor..." }));
        } else {
            // Beğeni, Yorum, Paylaşım Görevleri
            if (accountData) {
                console.log(`[BOT] ${accountData.username} icin cerezler (cookies) yukleniyor...`);
            }
            
            console.log(`[BOT] Adrese gidiliyor: ${targetUrl}`);
            await page.goto(targetUrl, { waitUntil: 'networkidle2' });
            
            ws.send(JSON.stringify({ type: 'bot_log', message: `[${accountData ? accountData.username : 'GİZLİ'}] Sayfa yüklendi. ${actionType.toUpperCase()} işlemi yapılıyor...` }));
            
            await new Promise(r => setTimeout(r, 3000)); // Simüle edilmiş işlem süresi
            console.log("[BOT] Gorev tamamlandi.");
            ws.send(JSON.stringify({ type: 'bot_log', message: `[${accountData ? accountData.username : 'GİZLİ'}] İşlem başarıyla tamamlandı!` }));
        }

        await browser.close();

    } catch (error) {
        console.error("[BOT HATASI]", error);
        ws.send(JSON.stringify({ type: 'bot_log', message: `Bot başlatılamadı: ${error.message}` }));
    }
}
