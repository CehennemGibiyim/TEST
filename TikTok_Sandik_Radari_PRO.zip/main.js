// Lucide Icons Init
lucide.createIcons();

// --- TAB NAVIGATION ---
const tabs = {
    'tab-radar': 'view-radar',
    'tab-calc': 'view-calc',
    'tab-ai': 'view-ai'
};

Object.keys(tabs).forEach(tabId => {
    document.getElementById(tabId).addEventListener('click', (e) => {
        // Tab UI update
        Object.keys(tabs).forEach(t => {
            const btn = document.getElementById(t);
            btn.classList.remove('bg-yellow-500/20', 'text-yellow-400', 'border', 'border-yellow-500/30');
            btn.classList.add('text-gray-400');
        });
        const activeBtn = document.getElementById(tabId);
        activeBtn.classList.remove('text-gray-400');
        activeBtn.classList.add('bg-yellow-500/20', 'text-yellow-400', 'border', 'border-yellow-500/30');

        // View update
        Object.values(tabs).forEach(v => {
            document.getElementById(v).classList.add('hidden');
        });
        document.getElementById(tabs[tabId]).classList.remove('hidden');
    });
});

// --- STORAGE & DATABASE (Kalıcı Hedef Yayıncılar) ---
let trackedUsernames = [];

async function loadPersistedUsers() {
    try {
        const saved = await miniappsAI.storage.getItem('trackedUsernames');
        if (saved) {
            trackedUsernames = JSON.parse(saved);
            trackedUsernames.forEach(username => renderTrackedUserUI(username));
            updateEmptyUsersText();
            // Eğer WebSocket bağlıysa otomatik istek at
            if (ws && ws.readyState === WebSocket.OPEN) {
                trackedUsernames.forEach(username => {
                    ws.send(JSON.stringify({ action: 'add_user', username }));
                });
            }
        }
    } catch(e) {
        console.error("Storage yüklenemedi", e);
    }
}

async function savePersistedUsers() {
    try {
        await miniappsAI.storage.setItem('trackedUsernames', JSON.stringify(trackedUsernames));
    } catch(e) {
        console.error("Storage kaydedilemedi", e);
    }
}


// --- RADAR LOGIC (WebSocket) ---
let ws = null;
const btnConnectWs = document.getElementById('btnConnectWs');
const btnDisconnectWs = document.getElementById('btnDisconnectWs');
const wsStatusBadge = document.getElementById('wsStatusBadge');
const wsStatusText = document.getElementById('wsStatusText');
const radarPulse = document.getElementById('radarPulse');

const inputAddUser = document.getElementById('addUsername');
const btnAddUser = document.getElementById('btnAddUser');
const btnUploadTxt = document.getElementById('btnUploadTxt');
const fileTxtUpload = document.getElementById('fileTxtUpload');
const trackedUsersContainer = document.getElementById('trackedUsers');
const emptyUsersText = document.getElementById('emptyUsersText');

const chestsListContainer = document.getElementById('chestsList');
const emptyChestsText = document.getElementById('emptyChestsText');
const totalChestsFoundSpan = document.getElementById('totalChestsFound');
const sortChestsSelect = document.getElementById('sortChests');

let chestsData = []; // Array of { id, user, coins, duration, dropTime }
let chestsTotalCounter = 0;
let renderInterval = null;

// Geri sayım ve otomatik temizlik motoru (Her saniye çalışır)
function startChestTimerEngine() {
    if (renderInterval) clearInterval(renderInterval);
    renderInterval = setInterval(() => {
        const now = Date.now();
        let needsRender = false;
        
        chestsData = chestsData.filter(chest => {
            const elapsedSeconds = (now - chest.dropTime) / 1000;
            const remaining = Math.max(0, chest.duration - elapsedSeconds);
            
            // Eğer süre tamamen bittiyse (00:00)
            if (remaining <= 0) {
                if (!chest.graceStartTime) {
                    chest.graceStartTime = now; // Sürenin bittiği anı kaydet
                    needsRender = true;
                }
                
                // OTOMATİK TEMİZLEME: 3 Dakika (180 saniye) doldu mu?
                const graceElapsed = now - chest.graceStartTime;
                if (graceElapsed > 180000) { 
                    needsRender = true;
                    return false; // Array'den tamamen çıkart (Otomatik Silme)
                }
            } else {
                needsRender = true; // Saniye azaldığı için ekrana yansıt
            }
            return true;
        });

        if (needsRender) renderChests();
    }, 1000);
}

function connectWebSocket() {
    const url = document.getElementById('wsUrl').value;
    ws = new WebSocket(url);

    ws.onopen = () => {
        wsStatusBadge.className = "flex items-center space-x-2 px-3 py-1 rounded-full bg-green-500/10 border border-green-500/20 text-green-400";
        wsStatusBadge.innerHTML = `<div class="w-2 h-2 rounded-full bg-green-500 shadow-[0_0_5px_rgba(34,197,94,0.8)]"></div><span class="text-xs font-bold">Aktif</span>`;
        btnConnectWs.classList.add('hidden');
        btnDisconnectWs.classList.remove('hidden');
        radarPulse.classList.remove('hidden');
        
        startChestTimerEngine();

        // Daha önceden kayıtlı kullanıcıları otomatik ekle
        trackedUsernames.forEach(username => {
            ws.send(JSON.stringify({ action: 'add_user', username }));
        });
    };

    ws.onclose = () => {
        wsStatusBadge.className = "flex items-center space-x-2 px-3 py-1 rounded-full bg-red-500/10 border border-red-500/20 text-red-400";
        wsStatusBadge.innerHTML = `<div class="w-2 h-2 rounded-full bg-red-500 shadow-[0_0_5px_rgba(239,68,68,0.8)]"></div><span class="text-xs font-bold">Koptu</span>`;
        btnConnectWs.classList.remove('hidden');
        btnDisconnectWs.classList.add('hidden');
        radarPulse.classList.add('hidden');
        if (renderInterval) clearInterval(renderInterval);
    };

    ws.onerror = (err) => {
        console.error("WebSocket Hatası:", err);
    };

    ws.onmessage = (msg) => {
        try {
            const data = JSON.parse(msg.data);
            if (data.type === 'status') {
                const badge = document.getElementById(`status-${data.user}`);
                if (badge) {
                    if (data.status === 'connected') {
                        badge.className = "w-2.5 h-2.5 rounded-full bg-green-500 shadow-[0_0_8px_rgba(34,197,94,0.8)]";
                    } else {
                        badge.className = "w-2.5 h-2.5 rounded-full bg-red-500 shadow-[0_0_8px_rgba(239,68,68,0.8)]";
                    }
                }
            } else if (data.type === 'chest') {
                handleNewChest(data);
            }
        } catch(e) {
            console.error(e);
        }
    };
}

btnConnectWs.addEventListener('click', connectWebSocket);
btnDisconnectWs.addEventListener('click', () => {
    if (ws) ws.close();
});

// Input logic
inputAddUser.addEventListener('input', (e) => {
    btnAddUser.disabled = e.target.value.trim().length === 0;
});

// Metin ayıklayıcı (Regex ile nick veya link okuma)
function extractUsernames(text) {
    // Boşluk, virgül veya yeni satıra göre parçala
    const rawItems = text.split(/[\n,\s]+/);
    const validNames = [];
    
    rawItems.forEach(item => {
        let name = item.trim();
        if (!name) return;
        
        // Link içeriyorsa (ör: https://www.tiktok.com/@username)
        const match = name.match(/@([a-zA-Z0-9_.-]+)/);
        if (match) {
            name = match[1];
        } else {
            // @ işareti yoksa bile düz kelimeyi nick kabul et (başına @ eklenmişse temizle)
            name = name.replace(/^@/, '');
        }
        
        if (name.length > 0 && !validNames.includes(name)) {
            validNames.push(name);
        }
    });
    return validNames;
}

// Yeni hedefleri listeye ve storage'a ekleme fonksiyonu
async function addNewTargets(namesArray) {
    let addedCount = 0;
    namesArray.forEach(username => {
        if (!trackedUsernames.includes(username)) {
            trackedUsernames.push(username);
            renderTrackedUserUI(username);
            
            if (ws && ws.readyState === WebSocket.OPEN) {
                ws.send(JSON.stringify({ action: 'add_user', username }));
            }
            addedCount++;
        }
    });

    if (addedCount > 0) {
        updateEmptyUsersText();
        await savePersistedUsers();
    }
    return addedCount;
}

// Normal inputtan ekleme
btnAddUser.addEventListener('click', async () => {
    const val = inputAddUser.value.trim();
    if (!val) return;
    
    const names = extractUsernames(val);
    await addNewTargets(names);
    
    inputAddUser.value = '';
    btnAddUser.disabled = true;
});

// TXT'den yükleme
btnUploadTxt.addEventListener('click', () => {
    fileTxtUpload.click();
});

fileTxtUpload.addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = async (ev) => {
        const text = ev.target.result;
        const names = extractUsernames(text);
        
        if (names.length === 0) {
            alert("Dosyada geçerli bir kullanıcı adı veya TikTok linki bulunamadı.");
            return;
        }
        
        const added = await addNewTargets(names);
        alert(`${names.length} okundu, ${added} yeni kullanıcı veritabanına ve radara eklendi!`);
        fileTxtUpload.value = ""; // Reset
    };
    reader.readAsText(file);
});


function updateEmptyUsersText() {
    emptyUsersText.style.display = trackedUsernames.length === 0 ? 'block' : 'none';
}

function renderTrackedUserUI(username) {
    const div = document.createElement('div');
    div.id = `tracked-${username}`;
    div.className = "flex items-center justify-between bg-black/40 border border-white/5 rounded-xl p-3";
    
    div.innerHTML = `
        <div class="flex items-center space-x-3">
            <div id="status-${username}" class="w-2.5 h-2.5 rounded-full bg-yellow-500/50 shadow-[0_0_5px_rgba(250,204,21,0.5)] animate-pulse"></div>
            <span class="font-medium text-yellow-50">@${username}</span>
        </div>
        <button class="text-red-400 hover:text-red-300 p-1 bg-red-500/10 rounded-lg transition-colors border border-red-500/20" onclick="removeTrackedUser('${username}')" title="Listeden Sil">
            <i data-lucide="x" class="w-4 h-4"></i>
        </button>
    `;
    trackedUsersContainer.appendChild(div);
    lucide.createIcons();
}

window.removeTrackedUser = async function(username) {
    // 1. Arrayden çıkar
    trackedUsernames = trackedUsernames.filter(u => u !== username);
    
    // 2. UI'dan çıkar
    const el = document.getElementById(`tracked-${username}`);
    if (el) el.remove();
    updateEmptyUsersText();
    
    // 3. WS'ye bildir
    if (ws && ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify({ action: 'remove_user', username }));
    }
    
    // 4. Storage'a kaydet
    await savePersistedUsers();
};

function formatTimeRemaining(seconds) {
    const m = Math.floor(seconds / 60);
    const s = Math.floor(seconds % 60);
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
}

function handleNewChest(data) {
    chestsTotalCounter++;
    totalChestsFoundSpan.innerText = chestsTotalCounter;
    
    const chestId = 'chest_' + Date.now() + Math.floor(Math.random()*1000);
    
    chestsData.push({
        id: chestId,
        user: data.user,
        coins: typeof data.data.coins === 'number' ? data.data.coins : parseInt(data.data.coins) || 0,
        duration: data.data.duration,
        dropTime: Date.now(),
        timeStr: data.data.time,
        graceStartTime: null // Süresi bitince atanacak
    });
    
    renderChests();
}

// Custom Remove from UI (Manual)
window.removeChestFromUI = function(id) {
    chestsData = chestsData.filter(c => c.id !== id);
    renderChests();
};

function renderChests() {
    emptyChestsText.style.display = chestsData.length === 0 ? 'flex' : 'none';
    
    // Sorting logic
    const sortVal = sortChestsSelect.value;
    let sortedChests = [...chestsData];
    
    const now = Date.now();
    
    sortedChests.sort((a, b) => {
        const aRemain = Math.max(0, a.duration - (now - a.dropTime) / 1000);
        const bRemain = Math.max(0, b.duration - (now - b.dropTime) / 1000);
        
        if (sortVal === 'timeAsc') {
            // Süresi bitenleri en alta at (çünkü aktifler daha önemli)
            if (aRemain === 0 && bRemain > 0) return 1;
            if (bRemain === 0 && aRemain > 0) return -1;
            return aRemain - bRemain;
        } 
        else if (sortVal === 'coinsDesc') {
            return b.coins - a.coins;
        }
        else if (sortVal === 'expiredFirst') {
            if (aRemain === 0 && bRemain > 0) return -1;
            if (bRemain === 0 && aRemain > 0) return 1;
            return aRemain - bRemain;
        }
        return 0;
    });

    chestsListContainer.innerHTML = '';
    
    sortedChests.forEach(chest => {
        const elapsedSeconds = (now - chest.dropTime) / 1000;
        const remaining = Math.max(0, chest.duration - elapsedSeconds);
        const isExpired = remaining <= 0;
        
        // Progress bar percentage
        const progressPct = isExpired ? 0 : (remaining / chest.duration) * 100;
        
        let statusBadge = '';
        let containerBorder = 'border-yellow-500/20';
        let countdownColor = 'text-yellow-400';
        
        if (isExpired) {
            // Grace period (Bekleme Süresi) hesaplaması
            const graceElapsed = now - chest.graceStartTime;
            const graceRemainingSeconds = Math.max(0, Math.floor((180000 - graceElapsed) / 1000));
            
            containerBorder = 'border-red-500/50 bg-red-500/5';
            countdownColor = 'text-red-400 animate-pulse';
            statusBadge = `
                <div class="flex flex-col items-end">
                    <span class="bg-red-500 text-white text-xs px-2 py-0.5 rounded font-bold animate-pulse">KONTROL ET!</span>
                    <span class="text-[10px] text-red-400/70 mt-1">${graceRemainingSeconds}sn sonra silinecek</span>
                </div>
            `;
        } else {
            statusBadge = `<span class="bg-yellow-500/20 text-yellow-400 border border-yellow-500/30 text-xs px-2 py-1 rounded font-bold flex items-center"><i data-lucide="clock" class="w-3 h-3 mr-1"></i> ${formatTimeRemaining(remaining)}</span>`;
        }

        const div = document.createElement('div');
        div.className = `chest-anim bg-black/60 border ${containerBorder} rounded-2xl p-4 relative overflow-hidden transition-all`;
        
        div.innerHTML = `
            <div class="flex items-center justify-between mb-3 relative z-10">
                <div class="flex items-center space-x-3">
                    <div class="w-10 h-10 rounded-xl bg-gradient-to-br from-yellow-400 to-amber-600 flex items-center justify-center shadow-[0_0_10px_rgba(250,204,21,0.3)]">
                        <i data-lucide="box" class="w-5 h-5 text-black"></i>
                    </div>
                    <div>
                        <h4 class="font-bold text-white text-lg">@${chest.user}</h4>
                        <p class="text-xs text-yellow-50/50">Düşme Zamanı: ${chest.timeStr}</p>
                    </div>
                </div>
                ${statusBadge}
            </div>
            
            <div class="flex items-center justify-between bg-black/40 rounded-xl p-3 border border-white/5 relative z-10">
                <div class="flex items-center">
                    <i data-lucide="coins" class="w-5 h-5 text-yellow-400 mr-2"></i>
                    <span class="font-black text-xl text-yellow-400">${chest.coins > 0 ? chest.coins + ' Jeton' : 'Bilinmiyor'}</span>
                </div>
                <div class="flex gap-2">
                    <a href="https://www.tiktok.com/@${chest.user}/live" target="_blank" class="bg-yellow-500 hover:bg-yellow-400 text-black px-4 py-1.5 rounded-lg font-bold text-sm transition-colors shadow-[0_0_10px_rgba(250,204,21,0.2)] flex items-center">
                        <i data-lucide="external-link" class="w-4 h-4 mr-1"></i> Git
                    </a>
                    ${isExpired ? `
                    <button onclick="removeChestFromUI('${chest.id}')" class="bg-red-500/20 hover:bg-red-500/40 text-red-400 border border-red-500/50 px-3 py-1.5 rounded-lg font-bold text-sm transition-colors flex items-center" title="Listeden Kaldır">
                        <i data-lucide="trash-2" class="w-4 h-4"></i>
                    </button>
                    ` : ''}
                </div>
            </div>
            
            <!-- Progress Bar -->
            <div class="absolute bottom-0 left-0 h-1 bg-gradient-to-r from-yellow-400 to-amber-600 transition-all duration-1000 ease-linear" style="width: ${progressPct}%"></div>
        `;
        chestsListContainer.appendChild(div);
    });
    
    lucide.createIcons();
}

sortChestsSelect.addEventListener('change', renderChests);

// --- CALCULATOR LOGIC ---
const pieCanvas = document.getElementById('revenuePieChart').getContext('2d');
let revenueChart = new Chart(pieCanvas, {
    type: 'doughnut',
    data: {
        labels: ['TikTok Kesintisi', 'Ajans Payı', 'Yayıncı Net'],
        datasets: [{
            data: [50, 10, 40],
            backgroundColor: ['#ef4444', '#f59e0b', '#facc15'],
            borderWidth: 0,
            hoverOffset: 10
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: { position: 'right', labels: { color: 'rgba(254,252,232,0.7)', font: { family: 'Inter' } } }
        },
        cutout: '75%'
    }
});

function calculateRevenue() {
    const coins = parseFloat(document.getElementById('calcCoins').value) || 0;
    const coinVal = parseFloat(document.getElementById('calcCoinValue').value) || 0;
    const usdRate = parseFloat(document.getElementById('calcUsdRate').value) || 0;
    const ttCut = parseFloat(document.getElementById('calcTiktokCut').value) || 0;
    const agCut = parseFloat(document.getElementById('calcAgencyCut').value) || 0;

    const grossUsd = coins * coinVal;
    const grossTry = grossUsd * usdRate;

    const afterTtUsd = grossUsd * (1 - ttCut/100);
    const agencyUsd = afterTtUsd * (agCut/100);
    const agencyTry = agencyUsd * usdRate;

    const netUsd = afterTtUsd - agencyUsd;
    const netTry = netUsd * usdRate;

    document.getElementById('resGrossUsd').innerText = '$' + grossUsd.toLocaleString('en-US', {minimumFractionDigits:2, maximumFractionDigits:2});
    document.getElementById('resGrossTry').innerText = grossTry.toLocaleString('tr-TR', {minimumFractionDigits:2, maximumFractionDigits:2}) + ' ₺';

    document.getElementById('resAgencyUsd').innerText = '$' + agencyUsd.toLocaleString('en-US', {minimumFractionDigits:2, maximumFractionDigits:2});
    document.getElementById('resAgencyTry').innerText = agencyTry.toLocaleString('tr-TR', {minimumFractionDigits:2, maximumFractionDigits:2}) + ' ₺';

    document.getElementById('resNetUsd').innerText = '$' + netUsd.toLocaleString('en-US', {minimumFractionDigits:2, maximumFractionDigits:2});
    document.getElementById('resNetTry').innerText = netTry.toLocaleString('tr-TR', {minimumFractionDigits:2, maximumFractionDigits:2}) + ' ₺';

    // Update Chart
    const netPct = 100 - ttCut - agCut;
    revenueChart.data.datasets[0].data = [ttCut, agCut, netPct];
    revenueChart.update();
}

['calcCoins', 'calcCoinValue', 'calcUsdRate', 'calcTiktokCut', 'calcAgencyCut'].forEach(id => {
    document.getElementById(id).addEventListener('input', calculateRevenue);
});
calculateRevenue();

// --- AI LOGIC ---
const btnAnalyze = document.getElementById('btnAnalyze');
const aiInput = document.getElementById('aiInput');
const aiResult = document.getElementById('aiResult');
const aiLoading = document.getElementById('aiLoading');

btnAnalyze.addEventListener('click', async () => {
    const text = aiInput.value.trim();
    if(!text) return alert("Lütfen analiz edilecek sohbet dökümünü veya notları girin.");

    aiLoading.classList.remove('hidden');
    aiResult.innerHTML = '';

    try {
        const response = await miniappsAI.callModel({
            modelId: "b85108b5-3d84-48db-9d8e-329ab0dceab1", // Text model (GPT-4o mini via UUID)
            messages: [
                {
                    role: "system",
                    content: "Sen bir TikTok yayın ajansı uzmanısın. Gönderilen yayın sohbeti veya notlarını analiz et. Yayıncıya tavsiyeler ver, kitlenin duygu durumunu özetle ve daha çok jeton/hediye alması için taktikler sun. Sadece Markdown formatında, şık ve profesyonel bir rapor ver."
                },
                {
                    role: "user",
                    content: text
                }
            ]
        });

        const resultText = miniappsAI.extractText(response);
        aiResult.innerHTML = `<div class="prose prose-invert prose-yellow max-w-none text-sm leading-relaxed">${resultText.replace(/\n/g, '<br>')}</div>`;
        
    } catch(err) {
        console.error(err);
        aiResult.innerHTML = `<div class="text-red-400 p-4 bg-red-500/10 rounded-xl border border-red-500/20"><i data-lucide="alert-circle" class="w-5 h-5 inline mr-2"></i> Yapay zeka ile iletişim kurulamadı. Hata: ${err.message}</div>`;
        lucide.createIcons();
    } finally {
        aiLoading.classList.add('hidden');
    }
});

// --- DOWNLOAD PROJECT LOGIC ---
document.getElementById('btnDownloadProject').addEventListener('click', async () => {
    const zip = new JSZip();
    
    try {
        // Files to fetch from workspace
        const files = [
            'index.html',
            'styles.css',
            'main.js',
            'server.js',
            'package.json',
            'baslat.bat'
        ];

        for (const file of files) {
            const resp = await fetch(file);
            const content = await resp.text();
            zip.file(file, content);
        }

        // Generate and download
        const blob = await zip.generateAsync({type: "blob"});
        saveAs(blob, "TikTok_Sandik_Radari_PRO.zip");
        alert("Proje başarıyla indirildi. Lütfen masaüstüne çıkartın ve baslat.bat dosyasını çalıştırın.");
    } catch (e) {
        console.error("İndirme hatası:", e);
        alert("Projeyi indirirken bir hata oluştu.");
    }
});

// --- INIT ---
// Sayfa yüklendiğinde hafızadaki kullanıcıları çek
loadPersistedUsers();
