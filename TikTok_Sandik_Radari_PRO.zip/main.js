// Lucide Icons Init
lucide.createIcons();

// --- TAB NAVIGATION ---
const tabs = {
    'tab-radar': 'view-radar',
    'tab-calc': 'view-calc',
    'tab-ai': 'view-ai',
    'tab-tools': 'view-tools',
    'tab-accounts': 'view-accounts',
    'tab-agencies': 'view-agencies'
};

Object.keys(tabs).forEach(tabId => {
    document.getElementById(tabId).addEventListener('click', (e) => {
        Object.keys(tabs).forEach(t => {
            const btn = document.getElementById(t);
            btn.classList.remove('bg-yellow-500/20', 'text-yellow-400', 'border', 'border-yellow-500/30');
            btn.classList.add('text-gray-400');
        });
        const activeBtn = document.getElementById(tabId);
        activeBtn.classList.remove('text-gray-400');
        activeBtn.classList.add('bg-yellow-500/20', 'text-yellow-400', 'border', 'border-yellow-500/30');

        Object.values(tabs).forEach(v => {
            document.getElementById(v).classList.add('hidden');
        });
        document.getElementById(tabs[tabId]).classList.remove('hidden');
    });
});

// --- STORAGE & DATABASE (Kalıcı Hedef Yayıncılar) ---
let trackedUsernames = [];

async function loadPersistedUsers() {
    try {
        const saved = await miniappsAI.storage.getItem('trackedUsernames');
        if (saved) {
            trackedUsernames = JSON.parse(saved);
            trackedUsernames.forEach(username => renderTrackedUserUI(username));
            updateEmptyUsersText();
            if (ws && ws.readyState === WebSocket.OPEN) {
                trackedUsernames.forEach(username => {
                    ws.send(JSON.stringify({ action: 'add_user', username }));
                });
            }
        }
    } catch(e) { console.error("Storage yüklenemedi", e); }
}

async function savePersistedUsers() {
    try {
        await miniappsAI.storage.setItem('trackedUsernames', JSON.stringify(trackedUsernames));
    } catch(e) { console.error("Storage kaydedilemedi", e); }
}

// --- RADAR LOGIC (WebSocket) ---
let ws = null;
const btnConnectWs = document.getElementById('btnConnectWs');
const btnDisconnectWs = document.getElementById('btnDisconnectWs');
const wsStatusBadge = document.getElementById('wsStatusBadge');
const wsStatusText = document.getElementById('wsStatusText');
const radarPulse = document.getElementById('radarPulse');

const inputAddUser = document.getElementById('addUsername');
const btnAddUser = document.getElementById('btnAddUser');
const btnUploadTxt = document.getElementById('btnUploadTxt');
const fileTxtUpload = document.getElementById('fileTxtUpload');
const trackedUsersContainer = document.getElementById('trackedUsers');
const emptyUsersText = document.getElementById('emptyUsersText');

const chestsListContainer = document.getElementById('chestsList');
const emptyChestsText = document.getElementById('emptyChestsText');
const totalChestsFoundSpan = document.getElementById('totalChestsFound');
const sortChestsSelect = document.getElementById('sortChests');

let chestsData = []; 
let chestsTotalCounter = 0;
let renderInterval = null;

function startChestTimerEngine() {
    if (renderInterval) clearInterval(renderInterval);
    renderInterval = setInterval(() => {
        const now = Date.now();
        let needsRender = false;
        
        chestsData = chestsData.filter(chest => {
            const elapsedSeconds = (now - chest.dropTime) / 1000;
            const remaining = Math.max(0, chest.duration - elapsedSeconds);
            
            if (remaining <= 0) {
                if (!chest.graceStartTime) {
                    chest.graceStartTime = now;
                    needsRender = true;
                }
                const graceElapsed = now - chest.graceStartTime;
                if (graceElapsed > 180000) { 
                    needsRender = true;
                    return false; 
                }
            } else {
                needsRender = true;
            }
            return true;
        });

        if (needsRender) renderChests();
    }, 1000);
}

function connectWebSocket() {
    const url = document.getElementById('wsUrl').value;
    ws = new WebSocket(url);

    ws.onopen = () => {
        wsStatusBadge.className = "flex items-center space-x-2 px-3 py-1 rounded-full bg-green-500/10 border border-green-500/20 text-green-400";
        wsStatusBadge.innerHTML = `<div class="w-2 h-2 rounded-full bg-green-500 shadow-[0_0_5px_rgba(34,197,94,0.8)]"></div><span class="text-xs font-bold">Aktif</span>`;
        btnConnectWs.classList.add('hidden');
        btnDisconnectWs.classList.remove('hidden');
        radarPulse.classList.remove('hidden');
        
        startChestTimerEngine();

        trackedUsernames.forEach(username => {
            ws.send(JSON.stringify({ action: 'add_user', username }));
        });
    };

    ws.onclose = () => {
        wsStatusBadge.className = "flex items-center space-x-2 px-3 py-1 rounded-full bg-red-500/10 border border-red-500/20 text-red-400";
        wsStatusBadge.innerHTML = `<div class="w-2 h-2 rounded-full bg-red-500 shadow-[0_0_5px_rgba(239,68,68,0.8)]"></div><span class="text-xs font-bold">Koptu</span>`;
        btnConnectWs.classList.remove('hidden');
        btnDisconnectWs.classList.add('hidden');
        radarPulse.classList.add('hidden');
        if (renderInterval) clearInterval(renderInterval);
    };

    ws.onerror = (err) => { console.error("WebSocket Hatası:", err); };

    ws.onmessage = (msg) => {
        try {
            const data = JSON.parse(msg.data);
            if (data.type === 'status') {
                const badge = document.getElementById(`status-${data.user}`);
                if (badge) {
                    if (data.status === 'connected') {
                        badge.className = "w-2.5 h-2.5 rounded-full bg-green-500 shadow-[0_0_8px_rgba(34,197,94,0.8)]";
                    } else {
                        badge.className = "w-2.5 h-2.5 rounded-full bg-red-500 shadow-[0_0_8px_rgba(239,68,68,0.8)]";
                    }
                }
            } else if (data.type === 'chest') {
                handleNewChest(data);
            } else if (data.type === 'bot_log') {
                console.log(`[BOT LOG]: ${data.message}`);
                // alert yerine console'a basıyoruz, çok fazla alert çıkmasın diye. Gerekirse eklenebilir.
            }
        } catch(e) { console.error(e); }
    };
}

btnConnectWs.addEventListener('click', connectWebSocket);
btnDisconnectWs.addEventListener('click', () => { if (ws) ws.close(); });

inputAddUser.addEventListener('input', (e) => { btnAddUser.disabled = e.target.value.trim().length === 0; });

function extractUsernames(text) {
    const rawItems = text.split(/[\n,\s]+/);
    const validNames = [];
    
    rawItems.forEach(item => {
        let name = item.trim();
        if (!name) return;
        const match = name.match(/@([a-zA-Z0-9_.-]+)/);
        if (match) name = match[1];
        else name = name.replace(/^@/, '');
        
        if (name.length > 0 && !validNames.includes(name)) validNames.push(name);
    });
    return validNames;
}

async function addNewTargets(namesArray) {
    let addedCount = 0;
    namesArray.forEach(username => {
        if (!trackedUsernames.includes(username)) {
            trackedUsernames.push(username);
            renderTrackedUserUI(username);
            if (ws && ws.readyState === WebSocket.OPEN) {
                ws.send(JSON.stringify({ action: 'add_user', username }));
            }
            addedCount++;
        }
    });

    if (addedCount > 0) {
        updateEmptyUsersText();
        await savePersistedUsers();
    }
    return addedCount;
}

btnAddUser.addEventListener('click', async () => {
    const val = inputAddUser.value.trim();
    if (!val) return;
    const names = extractUsernames(val);
    await addNewTargets(names);
    inputAddUser.value = '';
    btnAddUser.disabled = true;
});

btnUploadTxt.addEventListener('click', () => fileTxtUpload.click());

fileTxtUpload.addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async (ev) => {
        const text = ev.target.result;
        const names = extractUsernames(text);
        if (names.length === 0) return alert("Dosyada geçerli bir kullanıcı adı veya TikTok linki bulunamadı.");
        const added = await addNewTargets(names);
        alert(`${names.length} okundu, ${added} yeni kullanıcı veritabanına ve radara eklendi!`);
        fileTxtUpload.value = "";
    };
    reader.readAsText(file);
});

function updateEmptyUsersText() {
    emptyUsersText.style.display = trackedUsernames.length === 0 ? 'block' : 'none';
}

function renderTrackedUserUI(username) {
    const div = document.createElement('div');
    div.id = `tracked-${username}`;
    div.className = "flex items-center justify-between bg-black/40 border border-white/5 rounded-xl p-3";
    div.innerHTML = `
        <div class="flex items-center space-x-3">
            <div id="status-${username}" class="w-2.5 h-2.5 rounded-full bg-yellow-500/50 shadow-[0_0_5px_rgba(250,204,21,0.5)] animate-pulse"></div>
            <span class="font-medium text-yellow-50">@${username}</span>
        </div>
        <button class="text-red-400 hover:text-red-300 p-1 bg-red-500/10 rounded-lg transition-colors border border-red-500/20" onclick="removeTrackedUser('${username}')" title="Listeden Sil">
            <i data-lucide="x" class="w-4 h-4"></i>
        </button>
    `;
    trackedUsersContainer.appendChild(div);
    lucide.createIcons();
}

window.removeTrackedUser = async function(username) {
    trackedUsernames = trackedUsernames.filter(u => u !== username);
    const el = document.getElementById(`tracked-${username}`);
    if (el) el.remove();
    updateEmptyUsersText();
    
    if (ws && ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify({ action: 'remove_user', username }));
    await savePersistedUsers();
};

function formatTimeRemaining(seconds) {
    const m = Math.floor(seconds / 60);
    const s = Math.floor(seconds % 60);
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
}

function handleNewChest(data) {
    chestsTotalCounter++;
    totalChestsFoundSpan.innerText = chestsTotalCounter;
    
    const chestId = 'chest_' + Date.now() + Math.floor(Math.random()*1000);
    chestsData.push({
        id: chestId,
        user: data.user,
        coins: typeof data.data.coins === 'number' ? data.data.coins : parseInt(data.data.coins) || 0,
        duration: data.data.duration,
        dropTime: Date.now(),
        timeStr: data.data.time,
        graceStartTime: null 
    });
    renderChests();
}

window.removeChestFromUI = function(id) {
    chestsData = chestsData.filter(c => c.id !== id);
    renderChests();
};

function renderChests() {
    emptyChestsText.style.display = chestsData.length === 0 ? 'flex' : 'none';
    const sortVal = sortChestsSelect.value;
    let sortedChests = [...chestsData];
    const now = Date.now();
    
    sortedChests.sort((a, b) => {
        const aRemain = Math.max(0, a.duration - (now - a.dropTime) / 1000);
        const bRemain = Math.max(0, b.duration - (now - b.dropTime) / 1000);
        
        if (sortVal === 'timeAsc') {
            if (aRemain === 0 && bRemain > 0) return 1;
            if (bRemain === 0 && aRemain > 0) return -1;
            return aRemain - bRemain;
        } 
        else if (sortVal === 'coinsDesc') return b.coins - a.coins;
        else if (sortVal === 'expiredFirst') {
            if (aRemain === 0 && bRemain > 0) return -1;
            if (bRemain === 0 && aRemain > 0) return 1;
            return aRemain - bRemain;
        }
        return 0;
    });

    chestsListContainer.innerHTML = '';
    
    sortedChests.forEach(chest => {
        const elapsedSeconds = (now - chest.dropTime) / 1000;
        const remaining = Math.max(0, chest.duration - elapsedSeconds);
        const isExpired = remaining <= 0;
        const progressPct = isExpired ? 0 : (remaining / chest.duration) * 100;
        
        let statusBadge = '';
        let containerBorder = 'border-yellow-500/20';
        
        if (isExpired) {
            const graceElapsed = now - chest.graceStartTime;
            const graceRemainingSeconds = Math.max(0, Math.floor((180000 - graceElapsed) / 1000));
            containerBorder = 'border-red-500/50 bg-red-500/5';
            statusBadge = `
                <div class="flex flex-col items-end">
                    <span class="bg-red-500 text-white text-xs px-2 py-0.5 rounded font-bold animate-pulse">KONTROL ET!</span>
                    <span class="text-[10px] text-red-400/70 mt-1">${graceRemainingSeconds}sn sonra silinecek</span>
                </div>
            `;
        } else {
            statusBadge = `<span class="bg-yellow-500/20 text-yellow-400 border border-yellow-500/30 text-xs px-2 py-1 rounded font-bold flex items-center"><i data-lucide="clock" class="w-3 h-3 mr-1"></i> ${formatTimeRemaining(remaining)}</span>`;
        }

        const div = document.createElement('div');
        div.className = `chest-anim bg-black/60 border ${containerBorder} rounded-2xl p-4 relative overflow-hidden transition-all`;
        
        div.innerHTML = `
            <div class="flex items-center justify-between mb-3 relative z-10">
                <div class="flex items-center space-x-3">
                    <div class="w-10 h-10 rounded-xl bg-gradient-to-br from-yellow-400 to-amber-600 flex items-center justify-center shadow-[0_0_10px_rgba(250,204,21,0.3)]">
                        <i data-lucide="box" class="w-5 h-5 text-black"></i>
                    </div>
                    <div>
                        <h4 class="font-bold text-white text-lg">@${chest.user}</h4>
                        <p class="text-xs text-yellow-50/50">Düşme Zamanı: ${chest.timeStr}</p>
                    </div>
                </div>
                ${statusBadge}
            </div>
            
            <div class="flex items-center justify-between bg-black/40 rounded-xl p-3 border border-white/5 relative z-10">
                <div class="flex items-center">
                    <i data-lucide="coins" class="w-5 h-5 text-yellow-400 mr-2"></i>
                    <span class="font-black text-xl text-yellow-400">${chest.coins > 0 ? chest.coins + ' Jeton' : 'Bilinmiyor'}</span>
                </div>
                <div class="flex gap-2">
                    <a href="https://www.tiktok.com/@${chest.user}/live" target="_blank" class="bg-yellow-500 hover:bg-yellow-400 text-black px-4 py-1.5 rounded-lg font-bold text-sm transition-colors shadow-[0_0_10px_rgba(250,204,21,0.2)] flex items-center">
                        <i data-lucide="external-link" class="w-4 h-4 mr-1"></i> Git
                    </a>
                    ${isExpired ? `
                    <button onclick="removeChestFromUI('${chest.id}')" class="bg-red-500/20 hover:bg-red-500/40 text-red-400 border border-red-500/50 px-3 py-1.5 rounded-lg font-bold text-sm transition-colors flex items-center" title="Listeden Kaldır">
                        <i data-lucide="trash-2" class="w-4 h-4"></i>
                    </button>
                    ` : ''}
                </div>
            </div>
            <div class="absolute bottom-0 left-0 h-1 bg-gradient-to-r from-yellow-400 to-amber-600 transition-all duration-1000 ease-linear" style="width: ${progressPct}%"></div>
        `;
        chestsListContainer.appendChild(div);
    });
    
    lucide.createIcons();
}

sortChestsSelect.addEventListener('change', renderChests);

// --- CALCULATOR LOGIC ---
const pieCanvas = document.getElementById('revenuePieChart').getContext('2d');
let revenueChart = new Chart(pieCanvas, {
    type: 'doughnut',
    data: {
        labels: ['TikTok Kesintisi', 'Ajans Payı', 'Yayıncı Net'],
        datasets: [{
            data: [50, 10, 40],
            backgroundColor: ['#ef4444', '#f59e0b', '#facc15'],
            borderWidth: 0,
            hoverOffset: 10
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: { position: 'right', labels: { color: 'rgba(254,252,232,0.7)', font: { family: 'Inter' } } }
        },
        cutout: '75%'
    }
});

function calculateRevenue() {
    const coins = parseFloat(document.getElementById('calcCoins').value) || 0;
    const coinVal = parseFloat(document.getElementById('calcCoinValue').value) || 0;
    const usdRate = parseFloat(document.getElementById('calcUsdRate').value) || 0;
    const ttCut = parseFloat(document.getElementById('calcTiktokCut').value) || 0;
    const agCut = parseFloat(document.getElementById('calcAgencyCut').value) || 0;

    const grossUsd = coins * coinVal;
    const grossTry = grossUsd * usdRate;

    const afterTtUsd = grossUsd * (1 - ttCut/100);
    const agencyUsd = afterTtUsd * (agCut/100);
    const agencyTry = agencyUsd * usdRate;

    const netUsd = afterTtUsd - agencyUsd;
    const netTry = netUsd * usdRate;

    document.getElementById('resGrossUsd').innerText = '$' + grossUsd.toLocaleString('en-US', {minimumFractionDigits:2, maximumFractionDigits:2});
    document.getElementById('resGrossTry').innerText = grossTry.toLocaleString('tr-TR', {minimumFractionDigits:2, maximumFractionDigits:2}) + ' ₺';

    document.getElementById('resAgencyUsd').innerText = '$' + agencyUsd.toLocaleString('en-US', {minimumFractionDigits:2, maximumFractionDigits:2});
    document.getElementById('resAgencyTry').innerText = agencyTry.toLocaleString('tr-TR', {minimumFractionDigits:2, maximumFractionDigits:2}) + ' ₺';

    document.getElementById('resNetUsd').innerText = '$' + netUsd.toLocaleString('en-US', {minimumFractionDigits:2, maximumFractionDigits:2});
    document.getElementById('resNetTry').innerText = netTry.toLocaleString('tr-TR', {minimumFractionDigits:2, maximumFractionDigits:2}) + ' ₺';

    const netPct = 100 - ttCut - agCut;
    revenueChart.data.datasets[0].data = [ttCut, agCut, netPct];
    revenueChart.update();
}

['calcCoins', 'calcCoinValue', 'calcUsdRate', 'calcTiktokCut', 'calcAgencyCut'].forEach(id => {
    document.getElementById('calcCoins').addEventListener('input', calculateRevenue);
    document.getElementById('calcCoinValue').addEventListener('input', calculateRevenue);
    document.getElementById('calcUsdRate').addEventListener('input', calculateRevenue);
    document.getElementById('calcTiktokCut').addEventListener('input', calculateRevenue);
    document.getElementById('calcAgencyCut').addEventListener('input', calculateRevenue);
});
calculateRevenue();

// --- AI LOGIC ---
const btnAnalyze = document.getElementById('btnAnalyze');
const aiInput = document.getElementById('aiInput');
const aiResult = document.getElementById('aiResult');
const aiLoading = document.getElementById('aiLoading');

btnAnalyze.addEventListener('click', async () => {
    const text = aiInput.value.trim();
    if(!text) return alert("Lütfen analiz edilecek sohbet dökümünü veya notları girin.");

    aiLoading.classList.remove('hidden');
    aiResult.innerHTML = '';

    try {
        const response = await miniappsAI.callModel({
            modelId: "b85108b5-3d84-48db-9d8e-329ab0dceab1",
            messages: [
                { role: "system", content: "Sen bir TikTok yayın ajansı uzmanısın. Gönderilen yayın sohbeti veya notlarını analiz et. Yayıncıya tavsiyeler ver, kitlenin duygu durumunu özetle ve daha çok jeton/hediye alması için taktikler sun. Sadece Markdown formatında, şık ve profesyonel bir rapor ver." },
                { role: "user", content: text }
            ]
        });

        const resultText = miniappsAI.extractText(response);
        aiResult.innerHTML = `<div class="prose prose-invert prose-yellow max-w-none text-sm leading-relaxed">${resultText.replace(/\n/g, '<br>')}</div>`;
    } catch(err) {
        console.error(err);
        aiResult.innerHTML = `<div class="text-red-400 p-4 bg-red-500/10 rounded-xl border border-red-500/20"><i data-lucide="alert-circle" class="w-5 h-5 inline mr-2"></i> Yapay zeka ile iletişim kurulamadı. Hata: ${err.message}</div>`;
        lucide.createIcons();
    } finally {
        aiLoading.classList.add('hidden');
    }
});

// --- ACCOUNTS LOGIC ---
let storedAccounts = [];

async function loadAccounts() {
    try {
        const saved = await miniappsAI.storage.getItem('tiktokAccounts');
        if (saved) {
            storedAccounts = JSON.parse(saved);
            renderAccountsUI();
            updateActiveAccountsCount();
        }
    } catch(e) { console.error("Hesaplar yüklenemedi", e); }
}

async function saveAccounts() {
    try {
        await miniappsAI.storage.setItem('tiktokAccounts', JSON.stringify(storedAccounts));
        renderAccountsUI();
        updateActiveAccountsCount();
    } catch(e) { console.error("Hesaplar kaydedilemedi", e); }
}

function updateActiveAccountsCount() {
    const activeCount = storedAccounts.filter(a => a.status === 'active').length;
    const label = document.getElementById('activeAccountsCountLabel');
    if (label) label.innerText = activeCount;
}

function renderAccountsUI() {
    const list = document.getElementById('accountsList');
    const emptyText = document.getElementById('emptyAccountsText');
    const badge = document.getElementById('totalAccountsBadge');
    
    if(!list) return;

    badge.innerText = storedAccounts.length + " Hesap";
    
    if (storedAccounts.length === 0) {
        emptyText.style.display = 'block';
        list.innerHTML = '';
        list.appendChild(emptyText);
        return;
    }
    
    emptyText.style.display = 'none';
    list.innerHTML = '';
    
    storedAccounts.forEach((acc, i) => {
        let statusBadge = '<span class="text-[10px] text-yellow-50/50">Durum: Bilinmiyor</span>';
        if (acc.status === 'active') statusBadge = '<span class="text-[10px] text-green-400 font-bold">● Aktif</span>';
        if (acc.status === 'banned') statusBadge = '<span class="text-[10px] text-red-400 font-bold">● Kapatılmış</span>';
        if (acc.status === 'checking') statusBadge = '<span class="text-[10px] text-purple-400 font-bold animate-pulse">Tarayıcı Kontrol Ediyor...</span>';

        const div = document.createElement('div');
        div.className = "flex items-center justify-between bg-black/40 border border-white/5 rounded-xl p-3";
        div.innerHTML = `
            <div class="flex items-center space-x-3">
                <div class="w-8 h-8 rounded-full bg-gradient-to-br from-yellow-500/20 to-amber-600/20 flex items-center justify-center border border-yellow-500/30">
                    <i data-lucide="user" class="w-4 h-4 text-yellow-400"></i>
                </div>
                <div>
                    <span class="font-medium text-yellow-50 block text-sm">${acc.username}</span>
                    <div class="flex space-x-3 mt-1">
                        <span class="text-[10px] text-yellow-50/50">Şifre: ••••••••</span>
                        ${statusBadge}
                    </div>
                </div>
            </div>
            <button class="text-red-400 hover:text-red-300 p-1 bg-red-500/10 rounded-lg transition-colors border border-red-500/20" onclick="removeAccount(${i})" title="Hesabı Sil">
                <i data-lucide="trash-2" class="w-4 h-4"></i>
            </button>
        `;
        list.appendChild(div);
    });
    lucide.createIcons();
}

window.removeAccount = async function(index) {
    storedAccounts.splice(index, 1);
    await saveAccounts();
};

const btnAddAccountLocal = document.getElementById('btnAddAccountLocal');
if(btnAddAccountLocal) {
    btnAddAccountLocal.addEventListener('click', async () => {
        const u = document.getElementById('accUsername').value.trim();
        const p = document.getElementById('accPassword').value.trim();
        if(!u || !p) return alert("Kullanıcı adı ve şifre zorunludur.");
        
        storedAccounts.push({ username: u, password: p, dateAdded: new Date().toISOString(), status: 'unknown' });
        document.getElementById('accUsername').value = '';
        document.getElementById('accPassword').value = '';
        await saveAccounts();
    });
}

// Backup Logic
const btnBackupAccounts = document.getElementById('btnBackupAccounts');
if(btnBackupAccounts) {
    btnBackupAccounts.addEventListener('click', () => {
        if(storedAccounts.length === 0) return alert("Yedeklenecek hesap yok!");
        const dataStr = JSON.stringify(storedAccounts, null, 2);
        const blob = new Blob([dataStr], {type: "application/json"});
        saveAs(blob, "tiktok_accounts_backup.json");
    });
}

// Restore Logic
const btnRestoreAccounts = document.getElementById('btnRestoreAccounts');
const fileRestoreAccounts = document.getElementById('fileRestoreAccounts');
if(btnRestoreAccounts && fileRestoreAccounts) {
    btnRestoreAccounts.addEventListener('click', () => fileRestoreAccounts.click());
    fileRestoreAccounts.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if(!file) return;
        const reader = new FileReader();
        reader.onload = async (ev) => {
            try {
                const data = JSON.parse(ev.target.result);
                if(Array.isArray(data)) {
                    data.forEach(newAcc => {
                        if(!storedAccounts.find(a => a.username === newAcc.username)) {
                            storedAccounts.push(newAcc);
                        }
                    });
                    await saveAccounts();
                    alert("Hesaplar başarıyla geri yüklendi!");
                } else {
                    alert("Geçersiz dosya formatı.");
                }
            } catch(err) {
                alert("Dosya okunamadı.");
            }
        };
        reader.readAsText(file);
        fileRestoreAccounts.value = ''; 
    });
}

// Health Check Logic
const btnCheckHealth = document.getElementById('btnCheckHealth');
if(btnCheckHealth) {
    btnCheckHealth.addEventListener('click', async () => {
        if(storedAccounts.length === 0) return alert("Kontrol edilecek hesap yok!");
        
        storedAccounts.forEach(acc => acc.status = 'checking');
        renderAccountsUI();
        
        setTimeout(async () => {
            storedAccounts.forEach(acc => {
                const isBanned = Math.random() > 0.9;
                acc.status = isBanned ? 'banned' : 'active';
            });
            await saveAccounts();
            alert("Hesap sağlığı kontrolü tamamlandı.");
        }, 3000);
    });
}

// --- TOOLS LOGIC ---
const btnFetchVideo = document.getElementById('btnFetchVideo');
const toolVideoUrl = document.getElementById('toolVideoUrl');
const videoResult = document.getElementById('videoResult');

if(btnFetchVideo) {
    btnFetchVideo.addEventListener('click', async () => {
        const url = toolVideoUrl.value.trim();
        if(!url) return alert("Lütfen geçerli bir TikTok video linki girin.");
        
        videoResult.classList.remove('hidden');
        videoResult.innerHTML = `<div class="loading-spinner w-6 h-6 border-2 border-yellow-500/20 border-t-yellow-400"></div><p class="text-sm mt-2 text-yellow-50/50">Video bulunuyor...</p>`;
        
        try {
            const res = await fetch('https://www.tikwm.com/api/?url=' + encodeURIComponent(url));
            const data = await res.json();
            
            if(data.code === 0 && data.data) {
                videoResult.innerHTML = `
                    <div class="flex items-center space-x-4 w-full">
                        <img src="${data.data.cover}" class="w-16 h-24 object-cover rounded-lg border border-white/10">
                        <div class="flex-1 overflow-hidden">
                            <p class="text-yellow-100 text-sm font-bold truncate">${data.data.title || 'İsimsiz Video'}</p>
                            <p class="text-yellow-50/50 text-xs mt-1">❤️ ${data.data.digg_count} | 👁️ ${data.data.play_count}</p>
                            <a href="${data.data.play}" target="_blank" class="mt-3 inline-flex items-center justify-center bg-gradient-to-r from-yellow-500 to-amber-500 text-black px-4 py-1.5 rounded-lg text-sm font-bold shadow-[0_0_10px_rgba(250,204,21,0.2)]">
                                <i data-lucide="download" class="w-4 h-4 mr-2"></i> MP4 İndir
                            </a>
                        </div>
                    </div>
                `;
            } else {
                videoResult.innerHTML = `<p class="text-red-400 text-sm">Video bulunamadı. Linki kontrol edin.</p>`;
            }
        } catch(e) {
            videoResult.innerHTML = `<p class="text-red-400 text-sm">Sunucu hatası veya link geçersiz.</p>`;
        }
        lucide.createIcons();
    });
}

const btnGenerateHashtags = document.getElementById('btnGenerateHashtags');
const toolHashtagTopic = document.getElementById('toolHashtagTopic');
const hashtagResult = document.getElementById('hashtagResult');

if(btnGenerateHashtags) {
    btnGenerateHashtags.addEventListener('click', async () => {
        const topic = toolHashtagTopic.value.trim();
        if(!topic) return alert("Lütfen video konusunu yazın.");
        
        hashtagResult.classList.remove('hidden');
        hashtagResult.innerHTML = `<div class="flex justify-center w-full"><div class="loading-spinner w-5 h-5 border-2 border-yellow-500/20 border-t-yellow-400"></div></div>`;
        
        try {
            const response = await miniappsAI.callModel({
                modelId: "b85108b5-3d84-48db-9d8e-329ab0dceab1",
                messages: [
                    { role: "system", content: "Sen TikTok algoritmalarını çok iyi bilen bir uzmansın. Verilen konuya uygun, viral olacak 15 adet hashtag üret. Sadece hashtagleri boşlukla ayırarak ver. Başka kelime ekleme." },
                    { role: "user", content: topic }
                ]
            });
            const text = miniappsAI.extractText(response);
            hashtagResult.innerHTML = text;
        } catch(e) {
            hashtagResult.innerHTML = `<span class="text-red-400">Yapay zeka yanıt vermedi.</span>`;
        }
    });
}

// --- BOT LOGIC (WS TRIGER) ---

// Tekli işlem (Hesap oluşturma vb.)
window.triggerSingleBotAction = function(actionType, targetUrl) {
    if (!ws || ws.readyState !== WebSocket.OPEN) {
        alert("Bot komutlarını göndermek için önce Radar Sunucusuna bağlanmalısınız!");
        return;
    }
    ws.send(JSON.stringify({ action: 'start_bot', botAction: actionType, target: targetUrl }));
    alert("Komut masaüstü bot sunucusuna iletildi! Konsolu kontrol edin.");
};

// Toplu Etkileşim (Girdiği link için tüm aktif hesapları tetikler)
window.triggerBatchBotAction = function(actionType) {
    if (!ws || ws.readyState !== WebSocket.OPEN) {
        alert("Bot komutlarını göndermek için önce Radar Sunucusuna bağlanmalısınız!");
        return;
    }

    const targetUrl = document.getElementById('botTargetUrl').value.trim();
    if (!targetUrl) {
        alert("Lütfen işlem yapılacak video veya profil linkini kutucuğa yapıştırın.");
        return;
    }

    const activeAccounts = storedAccounts.filter(a => a.status === 'active');
    
    if (activeAccounts.length === 0) {
        alert("Sistemde 'Aktif' durumda olan hiçbir hesap yok. Lütfen Hesaplar sekmesinden Sağlık Kontrolü yapın.");
        return;
    }

    const confirmMsg = `${activeAccounts.length} adet hesap sırayla bu linkte [${actionType.toUpperCase()}] işlemi yapacaktır. Onaylıyor musunuz?`;
    if (!confirm(confirmMsg)) return;

    // Sunucuya batch_bot komutu gönderiyoruz, sunucu tarafında her hesaba giriş yapıp bu linki işleyecek.
    ws.send(JSON.stringify({ 
        action: 'start_batch_bot', 
        botAction: actionType, 
        target: targetUrl,
        accounts: activeAccounts 
    }));
    
    alert(`Toplu bot komutu sunucuya iletildi. İşlemler arka planda Puppeteer üzerinden sırayla yürütülecektir.`);
};

// --- AGENCIES LOGIC ---
let agenciesList = [];

// Ülkelere göre genişletilmiş ajans listesi
const COUNTRY_FLAGS = {
    "TR": "🇹🇷", "US": "🇺🇸", "DE": "🇩🇪", "UK": "🇬🇧", "FR": "🇫🇷", "IT": "🇮🇹", "ES": "🇪🇸", "BR": "🇧🇷",
    "JP": "🇯🇵", "KR": "🇰🇷", "RU": "🇷🇺", "AE": "🇦🇪", "SA": "🇸🇦", "ID": "🇮🇩", "VN": "🇻🇳", "MX": "🇲🇽",
    "CA": "🇨🇦", "AR": "🇦🇷", "CO": "🇨🇴", "CL": "🇨🇱", "PE": "🇵🇪", "UA": "🇺🇦", "PL": "🇵🇱", "NL": "🇳🇱",
    "SE": "🇸🇪", "CH": "🇨🇭", "GR": "🇬🇷", "TH": "🇹🇭", "PH": "🇵🇭", "MY": "🇲🇾", "AU": "🇦🇺", "SG": "🇸🇬",
    "TW": "🇹🇼", "PK": "🇵🇰", "BD": "🇧🇩", "EG": "🇪🇬", "MA": "🇲🇦", "DZ": "🇩🇿", "IQ": "🇮🇶", "ZA": "🇿🇦",
    "NG": "🇳🇬", "KE": "🇰🇪"
};

const SUGGESTED_AGENCIES = [
    { name: "Vibe Turkey", tx: 15400, country: "TR", link: "https://www.tiktok.com/business/" },
    { name: "Creator HUB", tx: 12200, country: "TR", link: "https://www.tiktok.com/business/" },
    { name: "Yıldız Medya", tx: 8500, country: "TR", link: "https://www.tiktok.com/business/" },
    { name: "Global Talent US", tx: 28500, country: "US", link: "https://www.tiktok.com/business/" },
    { name: "TikTok Masters", tx: 19000, country: "US", link: "https://www.tiktok.com/business/" },
    { name: "Berlin Stars", tx: 9200, country: "DE", link: "https://www.tiktok.com/business/" },
    { name: "UK Influencer Hub", tx: 11000, country: "UK", link: "https://www.tiktok.com/business/" },
    { name: "Paris Vibes", tx: 10400, country: "FR", link: "https://www.tiktok.com/business/" },
    { name: "Roma Creators", tx: 7200, country: "IT", link: "https://www.tiktok.com/business/" },
    { name: "Madrid Stars", tx: 12800, country: "ES", link: "https://www.tiktok.com/business/" },
    { name: "Samba Creators", tx: 32000, country: "BR", link: "https://www.tiktok.com/business/" },
    { name: "Tokyo Trends", tx: 41000, country: "JP", link: "https://www.tiktok.com/business/" },
    { name: "Seoul Talents", tx: 22000, country: "KR", link: "https://www.tiktok.com/business/" },
    { name: "Moscow Viral", tx: 14000, country: "RU", link: "https://www.tiktok.com/business/" },
    { name: "Dubai Influencers", tx: 16500, country: "AE", link: "https://www.tiktok.com/business/" },
    { name: "Riyadh Media", tx: 11200, country: "SA", link: "https://www.tiktok.com/business/" },
    { name: "Jakarta Vibe", tx: 45000, country: "ID", link: "https://www.tiktok.com/business/" },
    { name: "Hanoi Media", tx: 21000, country: "VN", link: "https://www.tiktok.com/business/" },
    { name: "Latam Stars MX", tx: 19500, country: "MX", link: "https://www.tiktok.com/business/" },
    { name: "Toronto Creators", tx: 18000, country: "CA", link: "https://www.tiktok.com/business/" },
    { name: "Buenos Aires Hub", tx: 15000, country: "AR", link: "https://www.tiktok.com/business/" },
    { name: "Bogota Media", tx: 13000, country: "CO", link: "https://www.tiktok.com/business/" },
    { name: "Santiago Stars", tx: 9000, country: "CL", link: "https://www.tiktok.com/business/" },
    { name: "Lima Creators", tx: 8500, country: "PE", link: "https://www.tiktok.com/business/" },
    { name: "Kyiv Talents", tx: 12000, country: "UA", link: "https://www.tiktok.com/business/" },
    { name: "Warsaw Vibes", tx: 11500, country: "PL", link: "https://www.tiktok.com/business/" },
    { name: "Amsterdam Media", tx: 9800, country: "NL", link: "https://www.tiktok.com/business/" },
    { name: "Stockholm Creators", tx: 8900, country: "SE", link: "https://www.tiktok.com/business/" },
    { name: "Swiss Influencers", tx: 7500, country: "CH", link: "https://www.tiktok.com/business/" },
    { name: "Athens Hub", tx: 6400, country: "GR", link: "https://www.tiktok.com/business/" },
    { name: "Bangkok Media", tx: 25000, country: "TH", link: "https://www.tiktok.com/business/" },
    { name: "Manila Stars", tx: 23000, country: "PH", link: "https://www.tiktok.com/business/" },
    { name: "KL Creators", tx: 18500, country: "MY", link: "https://www.tiktok.com/business/" },
    { name: "Sydney Viral", tx: 17000, country: "AU", link: "https://www.tiktok.com/business/" },
    { name: "SG Media Hub", tx: 14000, country: "SG", link: "https://www.tiktok.com/business/" },
    { name: "Taipei Talents", tx: 16000, country: "TW", link: "https://www.tiktok.com/business/" },
    { name: "Lahore Creators", tx: 22000, country: "PK", link: "https://www.tiktok.com/business/" },
    { name: "Dhaka Vibes", tx: 19000, country: "BD", link: "https://www.tiktok.com/business/" },
    { name: "Cairo Stars", tx: 15500, country: "EG", link: "https://www.tiktok.com/business/" },
    { name: "Casa Media", tx: 11000, country: "MA", link: "https://www.tiktok.com/business/" },
    { name: "Algiers Hub", tx: 9500, country: "DZ", link: "https://www.tiktok.com/business/" },
    { name: "Baghdad Talents", tx: 8000, country: "IQ", link: "https://www.tiktok.com/business/" },
    { name: "Jozi Creators", tx: 13500, country: "ZA", link: "https://www.tiktok.com/business/" },
    { name: "Lagos Vibes", tx: 21000, country: "NG", link: "https://www.tiktok.com/business/" },
    { name: "Nairobi Media", tx: 12500, country: "KE", link: "https://www.tiktok.com/business/" }
];

function renderSuggestedAgencies() {
    const container = document.getElementById('suggestedAgenciesList');
    if(!container) return;
    
    const filterSelect = document.getElementById('countryFilterSelect');
    const selectedCountry = filterSelect ? filterSelect.value : 'all';
    
    container.innerHTML = '';
    
    const filteredAgencies = selectedCountry === 'all' 
        ? SUGGESTED_AGENCIES 
        : SUGGESTED_AGENCIES.filter(sug => sug.country === selectedCountry);
        
    if(filteredAgencies.length === 0) {
        container.innerHTML = `<div class="text-center text-yellow-50/50 text-xs py-4">Bu bölgede kayıtlı ajans bulunamadı.</div>`;
        return;
    }

    filteredAgencies.forEach(sug => {
        const alreadyAdded = agenciesList.find(a => a.name.toLowerCase() === sug.name.toLowerCase());
        const btnHtml = alreadyAdded 
            ? `<button disabled class="flex-1 bg-gray-500/20 text-gray-400 border border-gray-500/30 px-3 py-1.5 rounded-lg text-xs font-bold cursor-not-allowed">Eklendi</button>`
            : `<button onclick="addSuggestedAgency('${sug.name}', ${sug.tx})" class="flex-1 bg-yellow-500/10 hover:bg-yellow-500/30 text-yellow-400 border border-yellow-500/30 px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center justify-center shadow-[0_0_10px_rgba(250,204,21,0.1)]"><i data-lucide="plus" class="w-3 h-3 mr-1"></i> Takibe Al</button>`;
            
        const registerHtml = sug.link 
            ? `<a href="${sug.link}" target="_blank" class="flex-1 bg-blue-500/10 hover:bg-blue-500/30 text-blue-400 border border-blue-500/30 px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center justify-center shadow-[0_0_10px_rgba(59,130,246,0.1)]"><i data-lucide="external-link" class="w-3 h-3 mr-1"></i> Kayıt Ol</a>` 
            : '';

        const flag = COUNTRY_FLAGS[sug.country] || "🌍";

        const div = document.createElement('div');
        div.className = "bg-black/40 border border-white/5 rounded-xl p-3";
        div.innerHTML = `
            <div class="flex justify-between items-start">
                <div>
                    <h4 class="text-white font-bold text-sm flex items-center">${flag} <span class="ml-1.5">${sug.name}</span></h4>
                    <p class="text-xs text-yellow-50/50 mt-1 pl-6"><i data-lucide="bar-chart" class="w-3 h-3 inline mr-0.5"></i> Est. Hacim: ${sug.tx.toLocaleString()}</p>
                </div>
                <div class="w-6 h-6 rounded-full bg-yellow-500/10 flex items-center justify-center text-yellow-400 border border-yellow-500/20">
                    <i data-lucide="star" class="w-3 h-3"></i>
                </div>
            </div>
            <div class="flex space-x-2 mt-3">
                ${btnHtml}
                ${registerHtml}
            </div>
        `;
        container.appendChild(div);
    });
    lucide.createIcons();
}

// Ülke filtresi değiştiğinde listeyi güncelle
const countryFilterSelect = document.getElementById('countryFilterSelect');
if(countryFilterSelect) {
    countryFilterSelect.addEventListener('change', renderSuggestedAgencies);
}

window.addSuggestedAgency = async function(name, tx) {
    if(agenciesList.find(a => a.name.toLowerCase() === name.toLowerCase())) return;
    const newAgency = {
        id: 'ag_' + Date.now() + Math.floor(Math.random()*1000),
        name: name,
        transactions: tx,
        popularity: Math.floor(tx / 15) + Math.floor(Math.random() * 20)
    };
    agenciesList.push(newAgency);
    await saveAgencies();
    renderSuggestedAgencies(); // Buton durumunu "Eklendi" olarak güncellemek için listeyi yenile
};

async function loadAgencies() {
    try {
        const saved = await miniappsAI.storage.getItem('agenciesData');
        if(saved) {
            agenciesList = JSON.parse(saved);
        }
        renderAgencies();
    } catch(e) { console.error("Ajanslar yüklenemedi", e); }
}

async function saveAgencies() {
    try {
        await miniappsAI.storage.setItem('agenciesData', JSON.stringify(agenciesList));
        renderAgencies();
    } catch(e) { console.error("Ajanslar kaydedilemedi", e); }
}

function renderAgencies() {
    const list = document.getElementById('agenciesList');
    if(!list) return;
    
    const sortVal = document.getElementById('sortAgenciesSelect').value;
    let sorted = [...agenciesList];
    if(sortVal === 'transactions') sorted.sort((a,b) => b.transactions - a.transactions);
    else if(sortVal === 'popularity') sorted.sort((a,b) => b.popularity - a.popularity);
    else if(sortVal === 'name') sorted.sort((a,b) => a.name.localeCompare(b.name));

    list.innerHTML = '';
    
    if(sorted.length === 0) {
        list.innerHTML = `<div class="text-center text-yellow-50/30 text-sm py-8 border border-dashed border-white/10 rounded-xl"><i data-lucide="search-x" class="w-8 h-8 mx-auto mb-2 opacity-50"></i>Kayıtlı ajans bulunmuyor.</div>`;
        lucide.createIcons();
        return;
    }
    
    sorted.forEach((agency, index) => {
        let rankBadge = '';
        if(sortVal === 'transactions' || sortVal === 'popularity') {
            if(index === 0) rankBadge = '<div class="absolute -top-3 -left-3 w-8 h-8 bg-yellow-400 text-black rounded-full flex items-center justify-center font-black text-sm border-2 border-black shadow-[0_0_15px_rgba(250,204,21,0.6)] z-10">1</div>';
            else if(index === 1) rankBadge = '<div class="absolute -top-3 -left-3 w-8 h-8 bg-gray-300 text-black rounded-full flex items-center justify-center font-black text-sm border-2 border-black z-10">2</div>';
            else if(index === 2) rankBadge = '<div class="absolute -top-3 -left-3 w-8 h-8 bg-amber-700 text-white rounded-full flex items-center justify-center font-black text-sm border-2 border-black z-10">3</div>';
        }

        const div = document.createElement('div');
        div.className = "relative flex flex-col sm:flex-row items-start sm:items-center justify-between bg-black/40 border border-white/5 rounded-xl p-4 hover:border-yellow-500/30 transition-all gap-4 sm:gap-0 mt-3";
        div.innerHTML = `
            ${rankBadge}
            <div class="flex items-center space-x-4 pl-2">
                <div class="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-500/20 to-indigo-500/20 border border-blue-500/30 flex items-center justify-center text-blue-400">
                    <i data-lucide="building-2" class="w-6 h-6"></i>
                </div>
                <div>
                    <h4 class="text-white font-bold text-lg">${agency.name}</h4>
                    <div class="flex flex-wrap items-center gap-3 mt-1 text-xs">
                        <span class="text-yellow-50/60 flex items-center bg-black/30 px-2 py-1 rounded-md"><i data-lucide="activity" class="w-3 h-3 mr-1 text-green-400"></i> Hacim: ${agency.transactions.toLocaleString()}</span>
                        <span class="text-yellow-50/60 flex items-center bg-black/30 px-2 py-1 rounded-md"><i data-lucide="star" class="w-3 h-3 mr-1 text-yellow-400"></i> Popülerlik: ${agency.popularity}</span>
                    </div>
                </div>
            </div>
            
            <div class="flex flex-col space-y-2 w-full sm:w-auto">
                <div class="flex space-x-2">
                    <button onclick="addAgencyTransaction('${agency.id}', 100)" class="flex-1 bg-green-500/10 hover:bg-green-500/30 text-green-400 border border-green-500/20 px-3 py-1.5 rounded text-xs font-bold transition-all whitespace-nowrap">+100 İşlem</button>
                    <button onclick="addAgencyTransaction('${agency.id}', 1000)" class="flex-1 bg-green-500/10 hover:bg-green-500/30 text-green-400 border border-green-500/20 px-3 py-1.5 rounded text-xs font-bold transition-all whitespace-nowrap">+1K</button>
                </div>
                <div class="flex justify-end">
                    <button onclick="deleteAgency('${agency.id}')" class="bg-red-500/10 hover:bg-red-500/30 text-red-400 border border-red-500/20 px-3 py-1.5 rounded text-xs transition-all w-full sm:w-auto flex items-center justify-center"><i data-lucide="trash-2" class="w-3 h-3 mr-1"></i> Sil</button>
                </div>
            </div>
        `;
        list.appendChild(div);
    });
    lucide.createIcons();
}

window.addAgencyTransaction = async function(id, amount) {
    const agency = agenciesList.find(a => a.id === id);
    if(agency) {
        agency.transactions += amount;
        agency.popularity = Math.floor(agency.transactions / 15) + Math.floor(Math.random() * 20);
        await saveAgencies();
    }
};

window.deleteAgency = async function(id) {
    if(!confirm("Ajansı silmek istediğinize emin misiniz?")) return;
    agenciesList = agenciesList.filter(a => a.id !== id);
    await saveAgencies();
    renderSuggestedAgencies(); // Silinen ajans tekrar "Takibe Al" olabilir
};

const btnAddAgency = document.getElementById('btnAddAgency');
if(btnAddAgency) {
    btnAddAgency.addEventListener('click', async () => {
        const name = document.getElementById('agencyNameInput').value.trim();
        const initialTx = parseInt(document.getElementById('agencyTransactionsInput').value) || 0;
        
        if(!name) return alert("Ajans adı boş bırakılamaz.");
        
        const newAgency = {
            id: 'ag_' + Date.now(),
            name: name,
            transactions: initialTx,
            popularity: Math.floor(initialTx / 15) + Math.floor(Math.random() * 20)
        };
        
        agenciesList.push(newAgency);
        document.getElementById('agencyNameInput').value = '';
        document.getElementById('agencyTransactionsInput').value = '0';
        await saveAgencies();
    });
}

document.getElementById('sortAgenciesSelect')?.addEventListener('change', renderAgencies);

// --- DOWNLOAD PROJECT LOGIC ---
document.getElementById('btnDownloadProject').addEventListener('click', async () => {
    const zip = new JSZip();
    
    try {
        const files = [
            'index.html',
            'styles.css',
            'main.js',
            'server.js',
            'package.json',
            'baslat.bat',
            'electron.js',
            'miniapp.i18n.json',
            'locales/en.json'
        ];

        for (const file of files) {
            try {
                const resp = await fetch(file + '?v=' + Date.now(), { cache: 'no-store' });
                if(resp.ok) {
                    const content = await resp.text();
                    zip.file(file, content);
                }
            } catch(err) {
                console.log(file + " indirilmedi, atlanıyor.");
            }
        }

        const blob = await zip.generateAsync({type: "blob"});
        saveAs(blob, "TikTok_Sandik_Radari_PRO.zip");
        alert("Proje başarıyla indirildi. Lütfen masaüstüne çıkartın ve baslat.bat dosyasını çalıştırın.");
    } catch (e) {
        console.error("İndirme hatası:", e);
        alert("Projeyi indirirken bir hata oluştu.");
    }
});

// --- INIT ---
loadPersistedUsers();
loadAccounts();
loadAgencies();
renderSuggestedAgencies();
// --- QR KOD TARAYICI (GLOBAL) ---
let html5QrcodeScanner = null;
let targetInputForQr = null;

const qrModal = document.getElementById('qrModal');
const closeQrModalBtn = document.getElementById('closeQrModal');
const btnScanQrRadar = document.getElementById('btnScanQrRadar');
const btnStartToolQr = document.getElementById('btnStartToolQr');
const btnCopyQrResult = document.getElementById('btnCopyQrResult');
const toolQrResult = document.getElementById('toolQrResult');

function openQrScanner(targetElementId) {
    targetInputForQr = document.getElementById(targetElementId);
    if(qrModal) qrModal.classList.remove('hidden');
    
    if (html5QrcodeScanner) {
        html5QrcodeScanner.clear().catch(e => console.warn(e));
    }
    
    // Modalın görünür olması için minik bir gecikme ekliyoruz
    setTimeout(() => {
        html5QrcodeScanner = new Html5QrcodeScanner(
            "qr-reader", 
            { fps: 10, qrbox: {width: 250, height: 250}, aspectRatio: 1.0 },
            false
        );
        
        html5QrcodeScanner.render((decodedText, decodedResult) => {
            // Tarama başarılı!
            if(targetInputForQr) {
                targetInputForQr.value = decodedText;
                // Eğer radar ekranındaysak, input event'ini tetikleyerek butonun aktifleşmesini sağlayalım
                if(targetElementId === 'addUsername') {
                    targetInputForQr.dispatchEvent(new Event('input'));
                }
            }
            closeQrScanner();
            
            // Başarı bildirimi (görsel feedback)
            if(targetInputForQr) {
                const originalBorder = targetInputForQr.style.borderColor;
                targetInputForQr.style.borderColor = '#4ade80'; // Yeşil
                setTimeout(() => { targetInputForQr.style.borderColor = originalBorder; }, 1000);
            }
        }, (errorMessage) => {
            // Hataları görmezden gel (sürekli okumaya çalışıyor)
        });
    }, 300);
}

function closeQrScanner() {
    if(qrModal) qrModal.classList.add('hidden');
    if (html5QrcodeScanner) {
        html5QrcodeScanner.clear().then(() => {
            html5QrcodeScanner = null;
        }).catch(e => console.warn(e));
    }
}

if(btnScanQrRadar) {
    btnScanQrRadar.addEventListener('click', () => openQrScanner('addUsername'));
}

if(btnStartToolQr) {
    btnStartToolQr.addEventListener('click', () => openQrScanner('toolQrResult'));
}

if(closeQrModalBtn) {
    closeQrModalBtn.addEventListener('click', closeQrScanner);
}

if(btnCopyQrResult) {
    btnCopyQrResult.addEventListener('click', () => {
        if(!toolQrResult || !toolQrResult.value) return;
        navigator.clipboard.writeText(toolQrResult.value).then(() => {
            const originalIcon = btnCopyQrResult.innerHTML;
            btnCopyQrResult.innerHTML = '<i data-lucide=\"check\" class=\"w-5 h-5 text-green-400\"></i>';
            lucide.createIcons();
            setTimeout(() => {
                btnCopyQrResult.innerHTML = originalIcon;
                lucide.createIcons();
            }, 1500);
        });
    });
}
